document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var login = document.getElementById('login').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    // Здесь вы можете отправить данные на сервер для обработки регистрации
    console.log('Login:', login);
    console.log('Email:', email);
    console.log('Password:', password);
    alert('Вы успешно зарегистрированы!');
});
